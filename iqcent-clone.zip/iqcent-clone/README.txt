IQCent Clone React App - Deployment Guide

1. Extract this zip file on your computer or phone.
2. Upload the 'iqcent-clone' folder to a GitHub repository.
3. Go to https://vercel.com/ and connect your GitHub account.
4. Import your 'iqcent-clone' repo in Vercel and click Deploy.
5. In 1-2 minutes, you'll get a live link to open on your mobile.

If you get stuck, ask ChatGPT for help with your GitHub repo link.